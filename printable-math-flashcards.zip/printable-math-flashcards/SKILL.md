---
name: printable-math-flashcards
description: Generate printable, duplex-aligned A4 landscape math flashcard PDFs for any topic such as multiplication tables, addition, subtraction, reducing fractions, or custom math exercises. Use when the user asks to create printable flashcards, duplex mirrored flashcard sheets, or cut-and-laminate math cards with front problems and 3-line centered back solutions.
---

# printable-math-flashcards

## Summary

Create print-ready A4 landscape PDF flashcard sheets designed for double-sided printing (flip on long edge), cutting, and laminating across any math topic. Cards use a clean white background, sharp rectangular corners, child-friendly chunky typography with colored fill and a black outline, and horizontally mirrored back pages with a 3-line centered answer layout.

## When to Use

- The user asks for printable flashcards for math topics such as multiplication, addition, subtraction, division, or reducing fractions.
- The user wants front-and-back flashcard sheets aligned for duplex printing or manual back-to-back assembly.
- The user wants to reuse the established flashcard layout for a new set of math problems.

## Steps

1. **Collect or generate the card pairs**: Build a list of `(front_text, back_lines)` pairs tailored to the requested math topic (for example, `3x4` on the front and `("3x4", "=", "12")` on the back, or `6/8` on the front and `("6/8", "=", "3/4")` on the back). Keep cards clean without extra caption text underneath.
2. **Configure A4 landscape grid layout**: Use A4 landscape dimensions (`842.28 x 595.27` points) with a `3x3` grid (9 cards per page) and rectangular cards wider than they are tall with sharp corners (`rx=0, ry=0`) and thin cutting border lines.
3. **Include header and footer**: Add a clear page header (title and brief printing/cutting/laminating guidance) and page footer (page numbering) on pages while keeping card cells clean.
4. **Style typography and colors**: Use a soft, rounded, child-friendly font style (such as Comic Sans / playful rounded sans-serif fallback if unavailable in the environment) at large sizes so text is easy to read. Fill text with varied bright colors and render a crisp black outline/stroke around the characters on a white card background.
5. **Mirror back pages for duplex alignment**: Group cards into pages of 9. For each back page, mirror columns horizontally (`col 0 <-> col 2` within each row) so that when flipped along the long edge in duplex printing or glued back-to-back, every front card aligns directly with its matching back card.
6. **Center back content on three lines**: On each back card, place the problem on line 1, `=` on line 2, and the answer/solution on line 3, all centered horizontally and vertically inside the card.
7. **Export the PDF**: Generate the final multi-page PDF and share it with the user.

## Gotchas

- Never forget to mirror columns horizontally on back pages (`[row][2], [row][1], [row][0]`), or front and back problems will mismatch after duplex printing or gluing.
- Keep card boxes white with sharp corners unless the user explicitly asks to change the card frame style.
- Do not add extra hint or table labels beneath the math expressions on the cards themselves; keep guidance in the page header/footer.
- If a specific font like Comic Sans is not installed in the sandbox environment, choose the closest rounded/friendly font available or draw bold outlined glyphs reliably so visual quality stays high.
