# Printable Math Flashcards Skill

En genanvendelig agent-skill til at generere udskriftsklare A4-flashcards i liggende format (landscape) til matematik — f.eks. gangetabeller, plus/minus, division eller forkortelse af brøker.

## Funktioner

- **A4 Landscape 3x3 gitter:** 9 rektangulære kort pr. side med skarpe hjørner og tynde skærelinjer.
- **Duplex-spejlvendte bagsider:** Kolonnerne på bagsiderne spejlvendes vandret (`kolonne 1 <-> kolonne 3`), så for- og bagside passer præcist over for hinanden ved to-sidet print ("vend om den lange side") eller sammenlimning.
- **3-linjers centreret bagside:** Viser regnestykket på linje 1, `=` på linje 2 og facit på linje 3.
- **Børnevenligt design:** Hvid baggrund, stor blød skrifttype med farvet fyld og sort kontur (stroke), samt overskuelig sidehoved- og sidefodsvejledning.

## Mappestruktur

```text
printable-math-flashcards/
├── SKILL.md
└── README.md
```

## Sådan bruger du den

1. Læg mappen `printable-math-flashcards/` ind i dit GitHub-repository eller din lokale skill-mappe.
2. Indlæs eller opret skillen ud fra `SKILL.md`.
3. Bed din AI-assistent om at lave et nyt sæt kort, f.eks.:
   > *"Lav printable flashcards med plus- og minusstykker op til 20 i samme layout som printable-math-flashcards."*
